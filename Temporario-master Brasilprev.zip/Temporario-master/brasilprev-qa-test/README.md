# Sobre o teste

O objetivo é criar testes para os cenários já criados no pacote de test.

Tecnologias: Junit, Cucumber e RestAssured ou MVC Test

# Dicas

1) Dê um fork neste projeto, clone e importe no IntelliJ, Eclipse ou IDE de preferência;

# Executar projeto
  Instalar as dependências
  `mvn clean install`
  
  Executar o projeto
  `mvn spring-boot:run`
