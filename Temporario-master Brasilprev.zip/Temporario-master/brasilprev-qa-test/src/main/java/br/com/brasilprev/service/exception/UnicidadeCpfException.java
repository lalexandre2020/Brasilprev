package br.com.brasilprev.service.exception;

public class UnicidadeCpfException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public UnicidadeCpfException(String msg) {
		super(msg);
	}

}
