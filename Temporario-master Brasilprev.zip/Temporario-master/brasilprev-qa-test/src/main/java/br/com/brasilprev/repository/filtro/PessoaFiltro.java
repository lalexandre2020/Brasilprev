package br.com.brasilprev.repository.filtro;

public class PessoaFiltro {

	private String nome;

	private String cpf;

	private String ddd;

	private String telefone;

	public String getNome() {
		return nome;
	}

	public String getTelefone() {
		return telefone;
	}
	
	public String getDdd() {
		return ddd;
	}

	public String getCpf() {
		return cpf;
	}
}
