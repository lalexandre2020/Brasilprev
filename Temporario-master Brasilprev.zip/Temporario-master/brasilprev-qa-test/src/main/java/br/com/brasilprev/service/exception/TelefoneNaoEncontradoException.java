package br.com.brasilprev.service.exception;

public class TelefoneNaoEncontradoException extends Exception {

	public TelefoneNaoEncontradoException(String msg) {
		super(msg);
	}

	private static final long serialVersionUID = 1L;

}
