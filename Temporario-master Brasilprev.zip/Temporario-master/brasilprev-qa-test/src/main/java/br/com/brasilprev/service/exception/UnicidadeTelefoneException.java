package br.com.brasilprev.service.exception;

public class UnicidadeTelefoneException extends Exception {

	private static final long serialVersionUID = 1L;

	public UnicidadeTelefoneException(String msg) {
		super(msg);
	}
}
